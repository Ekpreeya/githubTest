<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "data_emp";

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// รับค่า employee_id จากการสแกน QR Code
if (isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];

    // ตรวจสอบข้อมูลในฐานข้อมูล
    $stmt = $conn->prepare("SELECT nname, dept, gift_status FROM info WHERE id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ถ้าพบข้อมูลพนักงาน
        $row = $result->fetch_assoc();
        $nname = $row['nname'];
        $dept = $row['dept'];
        $gift_status = $row['gift_status'];

        if ($gift_status == 'yes') {
            // ถ้าได้รับของขวัญแล้ว
            header("Location: received_scanner.php?employee_id=$employee_id&nname=$nname&dept=$dept");
            exit();
        } else {
            // ถ้ายังไม่ได้รับของขวัญ
            header("Location: not_received_scanner.php?employee_id=$employee_id&nname=$nname&dept=$dept");
            exit();
        }
    } else {
        // ไม่พบข้อมูลพนักงาน
        header("Location: not_found_scanner.php?employee_id=" . urlencode($employee_id));
        exit();
    }
} else {
    // หากไม่มีการส่งค่า employee_id
    echo "ไม่มีการส่งค่า employee_id";
}

$conn->close();
?>