<?php
$servername = "localhost";
$username = "root"; // ชื่อผู้ใช้ที่เชื่อมต่อกับฐานข้อมูล
$password = ""; // รหัสผ่านฐานข้อมูล
$dbname = "data_emp"; // ชื่อฐานข้อมูล

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ตรวจสอบว่าเป็นการ POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับเลขพนักงานจากฟอร์ม
    $employee_id = $_POST['employee_id'];

    // ใช้ Prepared Statements เพื่อลดความเสี่ยงจาก SQL Injection
    $stmt = $conn->prepare("SELECT nname, dept, gift_status FROM info WHERE id = ?");
    $stmt->bind_param("i", $employee_id); // 'i' หมายถึง integer
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ถ้ามีข้อมูลในฐานข้อมูล
        $row = $result->fetch_assoc();
        $status = $row['gift_status'];
        $name = $row['nname'];
        $dept = $row['dept'];

        // ตรวจสอบสถานะ gift_status
        if ($status == 'yes') {
            echo "<h2>พนักงานหมายเลข $employee_id ($name) จากแผนก $dept ได้รับของขวัญแล้ว</h2>";
        } else {
            echo "<h2>พนักงานหมายเลข $employee_id ($name) จากแผนก $dept ยังไม่ได้รับของขวัญ</h2>";
        }
    } else {
        echo "<h2>ไม่พบข้อมูลพนักงานหมายเลข $employee_id</h2>";
    }

    $stmt->close();
}

$conn->close();
?>
