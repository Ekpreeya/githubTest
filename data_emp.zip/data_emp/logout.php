<?php
// logout.php

// เริ่มต้น Session
session_start();

// ทำลาย Session
session_unset();
session_destroy();

// นำผู้ใช้กลับไปยังหน้า login.php
header("Location: login.php");
exit();
?>
