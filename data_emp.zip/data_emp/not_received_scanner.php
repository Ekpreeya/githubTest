<?php
$employee_id = $_GET['employee_id'] ?? '';
$nname = $_GET['nname'] ?? '';
$dept = $_GET['dept'] ?? '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สถานะการรับของขวัญ</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="nav.css">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="image/STANLEY3.png" width="70" height="30" alt="Company Logo">
        </a>
        <!-- Icon Logout with Text -->
        <a class="logout-text d-flex align-items-center" href="logout.php">
            <span class="ms-2">Log out</span>
            <img src="image/logout-icon.png" width="24" height="24" alt="Logout Icon">
        </a>
    </div>
</nav>

    <!-- Content -->
    <div class="container mt-5">
        <div class="alert alert-warning text-center" role="alert">
            <h4 class="alert-heading">กำลังตรวจสอบข้อมูล...</h4>
            <p>พนักงานหมายเลข <strong><?php echo htmlspecialchars($employee_id); ?></strong> <br>
            คุณ <?php echo htmlspecialchars($nname); ?> จากแผนก <strong><?php echo htmlspecialchars($dept); ?></strong></p>
            <hr>
            <p class="text-muted">กำลังนำท่านไปยังหน้าอื่น...</p>
        </div>
    </div>

    <!-- Redirect after 2 seconds -->
    <script>
        // Get the values from PHP variables
        const employeeId = "<?php echo urlencode($employee_id); ?>";
        const nname = "<?php echo urlencode($nname); ?>";
        const dept = "<?php echo urlencode($dept); ?>";

        // Redirect to received_scanner.php with query parameters after 2 seconds
        setTimeout(function() {
            window.location.href = `received_scanner.php?employee_id=${employeeId}&nname=${nname}&dept=${dept}`;
        }, 2000); // 2000 milliseconds = 2 seconds
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
