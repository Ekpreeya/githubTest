<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ไม่พบข้อมูล</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="nav.css">
</head>
<body>
<?php
// ตรวจสอบว่ามีการส่ง employee_id มาหรือไม่
$employee_id = $_POST['employee_id'] ?? $_GET['employee_id'] ?? 'ไม่ระบุ';
?>
<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="image/STANLEY3.png" width="70" height="30" alt="Company Logo">
        </a>
        <!-- Icon Logout with Text -->
        <a class="logout-text d-flex align-items-center" href="logout.php">
            <span class="ms-2">Log out</span>
            <img src="image/logout-icon.png" width="24" height="24" alt="Logout Icon">
        </a>
    </div>
</nav>

<!-- Content -->
<div class="container mt-5">
    <div class="alert alert-danger text-center" role="alert">
        <h4 class="alert-heading">ไม่พบข้อมูลพนักงาน</h4>
        <p>ไม่พบข้อมูลพนักงานในระบบ<br>กรุณาตรวจสอบหมายเลข <strong><?php echo htmlspecialchars($employee_id); ?></strong> อีกครั้ง</p>
        <hr>
        <a href="index.php" class="btn btn-dark">กลับไปหน้าหลัก</a>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
