<?php
$employee_id = $_GET['employee_id'] ?? '';
$nname = $_GET['nname'] ?? '';
$dept = $_GET['dept'] ?? '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สถานะการรับของขวัญ</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .button-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        .btn-green {
            background-color: #28a745; /* สีเขียวสด */
            color: #fff;
            border: none;
        }
        .btn-green:hover {
            background-color: #218838; /* สีเขียวเข้มเมื่อ hover */
        }
        .btn-black {
            background-color: #000;
            color: #fff;
            border: none;
        }
        .btn-black:hover {
            background-color: #333;
        }
    </style>
    <link rel="stylesheet" href="nav.css">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="image/STANLEY3.png" width="70" height="30" alt="Company Logo">
        </a>
        <!-- Icon Logout with Text -->
        <a class="logout-text d-flex align-items-center" href="logout.php">
            <span class="ms-2">Log out</span>
            <img src="image/logout-icon.png" width="24" height="24" alt="Logout Icon">
        </a>
    </div>
</nav>

    <!-- Content -->
    <div class="container mt-5">
        <div class="alert alert-warning text-center" role="alert">
            <h4 class="alert-heading">ยังไม่ได้รับของขวัญ</h4>
            <p>พนักงานหมายเลข <strong><?php echo htmlspecialchars($employee_id); ?></strong> <br>
                คุณ <?php echo htmlspecialchars($nname); ?> จากแผนก <strong><?php echo htmlspecialchars($dept); ?></strong> <br>ยังไม่ได้รับของขวัญ</p>
            <hr>

            <!-- Button Container -->
            <div class="button-container">
                <!-- Back Button -->
                <a href="index.php" class="btn btn-black">กลับไปหน้าหลัก</a>
                
                <!-- Form for Receiving Gift -->
                <form method="post" action="received.php" style="margin: 0;">
                    <input type="hidden" name="employee_id" value="<?php echo htmlspecialchars($employee_id); ?>">
                    <input type="hidden" name="nname" value="<?php echo htmlspecialchars($nname); ?>">
                    <input type="hidden" name="dept" value="<?php echo htmlspecialchars($dept); ?>">
                    <button type="submit" class="btn btn-green">รับของขวัญ</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
