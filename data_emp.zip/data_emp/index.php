<?php
session_start();

// ตรวจสอบว่าผู้ใช้ล็อกอินแล้วหรือไม่
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตรวจสอบสถานะการรับของขวัญ</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>



<!-- Navbar -->
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="image/STANLEY3.png" width="70" height="30" alt="Company Logo">
        </a>
        <!-- Icon Logout with Text -->
        <a class="logout-text d-flex align-items-center" href="logout.php">
            <span class="ms-2">Log out</span>
            <img src="image/logout-icon.png" width="24" height="24" alt="Logout Icon">
        </a>
    </div>
</nav>


<!-- Main Container -->
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <div class="card shadow-lg p-5 rounded custom-card">
                <h2 class="text-center mb-4">ตรวจสอบสถานะการรับของขวัญ</h2>
                
                <!-- Form for Employee ID Check -->
                <form method="post" action="check_status.php">
                    <div class="mb-4">
                        <label for="employee_id" class="form-label">กรอกเลขพนักงานเพื่อตรวจสอบสถานะ</label>
                        <input type="text" id="employee_id" name="employee_id" class="form-control custom-input" placeholder="กรอกเลขพนักงาน">
                    </div>
                    <button type="submit" class="btn btn-orange w-100">ตรวจสอบ</button>
                </form>

                <hr class="my-5">

                <!-- QR Code Scanner Section -->
                <div class="container text-center">
                    <h4>หรือแสกน QR Code</h4>
                    <button class="btn btn-orange mb-3" onclick="openCamera()">เปิดกล้องสแกน QR Code</button>
                    <div id="camera" class="center-screen"></div>
                </div>
                
                <!-- QR Code Scanner Script -->
                <script src="https://cdn.jsdelivr.net/npm/html5-qrcode/minified/html5-qrcode.min.js"></script>
                <script>
                    function openCamera() {
                        const video = document.getElementById('camera');
                        video.style.display = 'block';

                        // ใช้ library html5-qrcode ในการสแกน
                        const html5QrCode = new Html5Qrcode("camera");

                        const qrCodeSuccessCallback = (decodedText) => {
                            console.log("QR Code Detected:", decodedText);
                            html5QrCode.stop().then(() => {
                                video.style.display = 'none';
                                window.location.href = "check_status_scanner.php?employee_id=" + decodedText;
                            }).catch(err => console.error("Failed to stop camera:", err));
                        };

                        html5QrCode.start(
                            { facingMode: "environment" }, 
                            { fps: 10, qrbox: { width: 250, height: 250 } }, 
                            qrCodeSuccessCallback
                        ).catch(err => console.error("Error accessing camera: " + err));
                    }
                </script>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="text-center py-3 custom-footer">
    <p class="mb-0">© 2024 Your Company. By Asian Stanley International Co. Ltd</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
