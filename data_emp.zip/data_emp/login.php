<?php
// เริ่มต้น session
session_start();

// ตรวจสอบการล็อกอิน
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['A_user'];
    $password = $_POST['A_pass'];

    // เชื่อมต่อกับฐานข้อมูล MySQL
    $servername = "localhost";
    $db_username = "root"; // ชื่อผู้ใช้ฐานข้อมูล
    $db_password = ""; // รหัสผ่านฐานข้อมูล (ถ้ามี)
    $dbname = "data_emp"; // ชื่อฐานข้อมูลของคุณ

    try {
        // สร้างการเชื่อมต่อกับฐานข้อมูล
        $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $db_username, $db_password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // เตรียมคำสั่ง SQL เพื่อดึงข้อมูล A_ID และ A_pass จากฐานข้อมูล
        $stmt = $pdo->prepare("SELECT A_name, A_ID, A_pass FROM admin WHERE A_ID = :A_user AND A_pass = :A_pass");
        $stmt->execute(['A_user' => $username, 'A_pass' => $password]);

        // ตรวจสอบผลลัพธ์
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // หากพบข้อมูลผู้ใช้ในฐานข้อมูล ให้ตั้งค่า session
            $_SESSION['loggedin'] = true;
            $_SESSION['A_user'] = $user['A_name']; // เก็บชื่อผู้ใช้ใน session
            header('Location: index.php'); // เปลี่ยนเส้นทางไปยังหน้า index.php
            exit;
        } else {
            // กรณีชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง
            $error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
        }
    } catch (PDOException $e) {
        echo "การเชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
        <h1>เข้าสู่ระบบ</h1>
        <form action="" method="post"> <!-- แก้ไขเป็น login.php -->
            <input type="text" name="A_user" placeholder="ชื่อผู้ใช้" required>
            <input type="password" name="A_pass" placeholder="รหัสผ่าน" required>
            <button type="submit">เข้าสู่ระบบ</button>
            <?php if (isset($error)) echo "<p class='text-danger'>$error</p>"; ?>
        </form>
    </div>
</body>
</html>
